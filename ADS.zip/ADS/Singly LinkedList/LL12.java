import java.util.*;
class LL12{


 public static void main(String args[]){
 
  LinkedList<String> list = new LinkedList<String>();
  list.addFirst("the");
  list.addFirst("one");
  System.out.println(list);
 
   } 

}
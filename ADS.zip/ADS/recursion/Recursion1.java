//infinite loop
class Recursion1{

  static  void display(){
 
 System.out.println("Hii Everyone!!!");
 
  display();
 }




    public static void main(String args[]){


          display();





}

}